import java.sql.*;


public class fsd_mysql {

    public static void main(String[] args) throws SQLException {

        String query="insert into tbl_emp (empcode, empname, empage, empsalary)\n" +
                "values(?,?,?,?)";
        Connection conn= DriverManager.getConnection("jdbc:mysql://localhost/fsd?user=root&password=MySql1991*");
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setInt(1, 102);
        ps.setString(2, "Jacky");
        ps.setInt(3, 30);
        ps.setInt(4, 20000);

        ps.addBatch();

        ps.setInt(1, 103);
        ps.setString(2, "Joe");
        ps.setInt(3, 20);
        ps.setInt(4, 40000);

        ps.addBatch();

        ps.setInt(1, 104);
        ps.setString(2, "John");
        ps.setInt(3, 40);
        ps.setInt(4, 80000);

        ps.addBatch();

        ps.setInt(1, 105);
        ps.setString(2, "Shameer");
        ps.setInt(3, 25);
        ps.setInt(4, 90000);

        ps.addBatch();

        ps.executeBatch();

        conn.close();
    }
}
